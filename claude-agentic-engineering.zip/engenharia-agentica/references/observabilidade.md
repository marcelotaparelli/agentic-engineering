# Observabilidade: gasto dos agentes e produto

A observabilidade cobre dois planos com perguntas diferentes. Eles se ligam pelo `feature.id` e pela versão de deploy.

| Plano | Perguntas | Fontes | Consumidores |
|---|---|---|---|
| **Agentes** | Quanto custou cada feature, cada agente e cada modelo? Onde o cache falhou? Quais ações foram bloqueadas ou aprovadas? O agente está gerando valor? | Telemetria OpenTelemetry do Claude Code, saídas JSON do CI, `status.md` | Techlead, finanças, humano que decide a ablação |
| **Produto** | O sistema funciona? Quão rápido? Onde quebrou? Alguém está atacando? Quem fez o quê? | Aplicação, infraestrutura, autenticação, trilha de auditoria | On-call, segurança, produto |

Sem o plano de agentes, o custo não tem dono. Sem o plano de produto, não há como saber se uma feature gerada pelo pipeline causou um incidente.

---

## 1. Plano de agentes

### 1.1 Habilitar a telemetria

Configure a exportação em **configurações gerenciadas**, no shell do ambiente controlado ou em `~/.claude/settings.json`. **Variáveis `OTEL_*` em `.claude/settings.json` e `.claude/settings.local.json` do repositório são ignoradas.** Um time que coloca a configuração no repositório acredita que está coletando e não coleta nada.

Variáveis principais:

| Variável | Valor | Função |
|---|---|---|
| `CLAUDE_CODE_ENABLE_TELEMETRY` | `1` | Liga a telemetria. Obrigatória |
| `OTEL_METRICS_EXPORTER` | `otlp` | Exporta métricas |
| `OTEL_LOGS_EXPORTER` | `otlp` | Exporta eventos de log |
| `OTEL_EXPORTER_OTLP_PROTOCOL` | `http/protobuf` ou `grpc` | Protocolo. Não há padrão |
| `OTEL_EXPORTER_OTLP_ENDPOINT` | URL do collector | Destino |
| `OTEL_RESOURCE_ATTRIBUTES` | `feature.id=<id>,team.id=<time>` | Atributos personalizados, incluídos nas métricas |
| `OTEL_METRIC_EXPORT_INTERVAL` | `60000` | Intervalo de métricas, em ms |
| `OTEL_LOGS_EXPORT_INTERVAL` | `5000` | Intervalo de logs, em ms |

Arquivo de referência: `templates/managed-settings-otel.json`.

**Atribuição por feature.** As configurações gerenciadas são globais, então o `feature.id` precisa vir do ambiente da sessão. Ao abrir a feature, exporte a variável no shell:

```bash
export OTEL_RESOURCE_ATTRIBUTES="feature.id=login-google,team.id=plataforma"
claude --agent techlead
```

O `scripts/novo-feature.sh` imprime essa linha para cada feature criada.

Para depurar a exportação, use `claude --debug-file <caminho>`. Erros dos seus exportadores aparecem marcados como `[3P telemetry]`. Linhas `[Anthropic telemetry]` são a telemetria operacional da própria Anthropic e não indicam erro na sua configuração.

**Traces são beta.** Para spans, habilite `CLAUDE_CODE_ENHANCED_TELEMETRY_BETA=1`, `OTEL_TRACES_EXPORTER=otlp` e o endpoint de traces (`OTEL_EXPORTER_OTLP_TRACES_ENDPOINT`). Use `TRACEPARENT` para ligar a sessão de agente ao trace da feature, quando a sessão for iniciada pelo SDK ou por `claude -p`.

### 1.2 Privacidade: o que fica desligado e por quê

Por padrão, prompts, respostas, conteúdo de ferramentas e corpos de API **não são exportados**. Mantenha assim em todo ambiente compartilhado.

| Variável | O que libera | Política |
|---|---|---|
| `OTEL_LOG_USER_PROMPTS=1` | Texto dos prompts | Desligado. Pode conter dados pessoais e trechos de código sensível |
| `OTEL_LOG_ASSISTANT_RESPONSES=1` | Texto das respostas | Desligado |
| `OTEL_LOG_TOOL_DETAILS=1` | Comandos Bash, caminhos, nomes de servidores e ferramentas MCP, e os nomes reais de agentes, skills e plugins nos contadores de custo | Ligar só em ambiente interno, se caminhos e comandos forem aceitáveis. **Sem ela, a atribuição de custo por agente, skill, plugin e servidor MCP não usa os nomes reais** |
| `OTEL_LOG_TOOL_CONTENT=1` | Conteúdo de saída das ferramentas | Desligado |
| `OTEL_LOG_RAW_API_BODIES` | JSON completo das requisições e respostas, com todo o histórico da conversa | **Nunca em ambiente compartilhado.** Grava código, segredos e dados pessoais que estiverem na conversa. Só para depuração isolada, com retenção curta |
| `OTEL_LOG_MANAGED_SETTINGS=1` | Configurações gerenciadas redigidas | Ligar para auditoria de conformidade |

Dois atributos carregam dados pessoais e devem ser tratados no collector (seção 5):

- `user.email`, quando disponível.
- `user.account_uuid` e `user.account_id`, que identificam a conta. O padrão é incluí-los nas métricas. Desligue na origem com `OTEL_METRICS_INCLUDE_ACCOUNT_UUID=false` ou remova no collector.

Para reduzir cardinalidade, use `OTEL_METRICS_INCLUDE_SESSION_ID=false` se o número de sessões estiver explodindo a métrica. O padrão é incluir `session.id`.

### 1.3 Métricas e o que cada uma responde

| Métrica | Unidade | Atributos principais | Pergunta respondida | KPI derivado |
|---|---|---|---|---|
| `claude_code.cost.usage` | USD | `model`, `query_source`, `agent.name`, `skill.name`, `plugin.name`, `mcp_server.name`, `effort`, `speed` | Quanto custou, por quê | **Custo por PR mergeado** = soma do custo por `feature.id` ÷ PRs da feature |
| `claude_code.token.usage` | tokens | `type` (`input`, `output`, `cacheRead`, `cacheCreation`), `model`, `query_source` | Onde está o volume | **Hit de cache** = `cacheRead` ÷ (`input` + `cacheRead` + `cacheCreation`) |
| `claude_code.code_edit_tool.decision` | contagem | `tool_name`, `decision` (`accept`, `reject`), `language` | Quanto o humano corrige o agente | **Taxa de rejeição** por agente e linguagem |
| `claude_code.session.count` | contagem | `start_type` (valores a confirmar com `--debug-file`) | Sessões novas ou retomadas | Retomadas com custo alto indicam cache frio |
| `claude_code.active_time.total` | s | `type` (`user`, `cli`) | Tempo de humano e de agente | Proxy de intervenção humana |
| `claude_code.commit.count` e `claude_code.pull_request.count` | contagem | — | Vazão | Denominador do custo por entrega |
| `claude_code.lines_of_code.count` | contagem | `type` (`added`, `removed`), `model` | Volume de alteração | Use só junto de defeitos de escape. Sozinha, incentiva código inchado |

`cost.usage` e `token.usage` são **estimativas**. A documentação não detalha a tabela de preços usada, então trate esses números como indicador de tendência, não como valor contábil. Concilie com o console ou com a fatura da nuvem todo mês.

Os atributos `agent.name`, `skill.name`, `plugin.name`, `mcp_server.name` e `mcp_tool.name` aparecem em custo e tokens **somente com `OTEL_LOG_TOOL_DETAILS=1`**. Sem essa flag, a atribuição por agente não tem nome. Os atributos `model`, `query_source`, `effort` e `speed` em `cost.usage` devem ser confirmados com `--debug-file` antes de montar o painel.

### 1.4 Eventos de log para auditoria

Os eventos se chamam `claude_code.<nome>`. Os principais para governança:

| Evento | Atributos úteis | Uso |
|---|---|---|
| `api_request` | `model`, `cost_usd`, `input_tokens`, `output_tokens`, `cache_read_tokens`, `cache_creation_tokens`, `query_source`, `effort` | Detectar requisições caras fora do padrão. Um agente em loop aparece aqui |
| `api_error` | `status_code`, `attempt`, `error`, `model` | Limites de taxa, falhas e retentativas. Alertar quando a taxa subir |
| `tool_decision` | `tool_name`, `decision`, `source`, `tool_source`, `classifier_verdict`, `permission_mode` | **Trilha de segurança.** Mostra quem aprovou o quê. Valores de `source`: `config`, `hook`, `user_permanent`, `user_temporary`, `user_abort`, `user_reject` |
| `safety_event` | `category`, `decision`, `decision_source`, `reason_code`, `rule_source`, `tool_class`, `tool_name`, `tool_source`, `permission_mode`, `tool_use_id`, `sandbox_violation_count`, `sandbox_enabled`, `circuit_breaker`, `hook_event` (requer v2.1.307+) | **Trilha de segurança.** Mostra cada recusa por regra, política gerenciada, modo, classificador, hook ou sandbox. Filtre `sandbox_violation_count` diferente de `"0"` para tentativas de acesso de rede bloqueadas |
| `tool_result` | `tool_name`, `success`, `duration_ms`, `error_type`, `decision_source`, `mcp_server_scope` | Confiabilidade das ferramentas, inclusive MCP |
| `permission_mode_changed` | `from_mode`, `to_mode`, `trigger` | Quando alguém ou algum gate mudou o modo de permissão, como sair do plan mode ou ativar `bypassPermissions` |
| `api_refusal` | `model`, `category`, `attempt` | Recusas do modelo. Picos em uma feature sugerem prompt ou contexto problemático |
| `subagent_completed`, `plugin_loaded`, `mcp_server_connection`, `managed_settings_resolved` | A documentação cita os nomes, mas não detalhou os atributos. Confirme com `--debug-file` antes de depender deles | Inventário e conformidade: quais plugins e servidores estavam ativos |

**Atributos de correlação** presentes nos eventos: `prompt.id`, `event.sequence`, `request_id`, `client_request_id` e `message.uuid`. Use `prompt.id` e `event.sequence` para ordenar o que aconteceu dentro de um turno. `request_id` liga uma chamada de API a seu custo e a seus tokens.

Para reconstruir a árvore de subagentes de uma feature, combine `subagent_completed` com `prompt.id`. Os atributos `agent_id` e `parent_agent_id` **não estão confirmados** na documentação lida. Confirme antes de usá-los.

### 1.5 Painéis mínimos do plano de agentes

1. **Custo por feature e por classe**, com tendência semanal e comparação com o teto de `status.md`.
2. **Custo por agente e por `query_source`** (`main`, `subagent`, `auxiliary`).
3. **Hit de cache por modelo**, com a tendência ao longo do mês.
4. **Taxa de rejeição de edição por agente e linguagem.**
5. **Aprovações permanentes e veredictos do classificador**, para auditoria.
6. **Erros de API e retentativas.**
7. **Retomadas de sessão com custo**, como sinal de cache frio.

### 1.6 Alertas do plano de agentes

Os limiares devem ser calibrados pela linha de base da equipe. Não use números genéricos.

- Feature acima de 100% do teto de tokens: pedir decisão humana.
- Custo de uma sessão acima de um limite definido, o que sugere loop de agente.
- Taxa de rejeição de edição acima do limiar da linha de base.
- Aprovação permanente (`user_permanent`) de ferramenta de risco, como Bash com escrita.
- Pico de `safety_event` em um intervalo curto.
- Hit de cache abaixo da mediana do mês.

---

## 2. Plano de produto

### 2.1 Os três sinais e os eventos de segurança

**Traces.** Use o SDK OpenTelemetry do projeto.
- Um span por requisição de entrada.
- Um span por chamada a dependência: banco, API externa, fila.
- Propague o contexto com `traceparent` (padrão W3C).
- Registre erros como eventos do span, com o tipo do erro.

**Métricas.**
- RED por endpoint: taxa de requisições, taxa de erros e histograma de duração.
- USE por recurso: utilização, saturação e erros.
- Métricas de negócio definidas na spec, com as mesmas regras de rótulo.

**Logs.**
- Estruturados, em JSON, com `trace_id` e `span_id`.
- Nível de severidade consistente.
- Sem dados pessoais, tokens ou segredos.
- Erro com contexto mínimo. Stack trace fica no log operacional, nunca em mensagem de usuário.

**Eventos de auditoria**, em pipeline separado, com retenção maior:
- Login, com sucesso e com falha.
- Mudança de permissão ou de papel.
- Acesso negado.
- Exportação ou download de dados.
- Ações administrativas.
- Validação de entrada rejeitada em volume.
- Rate limit atingido.

### 2.2 Cardinalidade e custo

- **Nunca** use `user_id`, e-mail, IP ou caminho com ID como rótulo de métrica. Cada valor único cria uma série nova e o custo explode.
- Use o template da rota (`/pedidos/{id}`), não o caminho real.
- Defina os buckets do histograma pela spec de latência.
- Amostragem de traces por cauda: mantenha todos os erros e as requisições lentas, e uma porcentagem das demais.
- Amostragem de logs de alto volume, sempre preservando erros.

### 2.3 SLO e alertas

- Um SLO por jornada do usuário, derivado dos requisitos não funcionais da spec: disponibilidade e latência p95 ou p99.
- Alertas por **taxa de consumo do orçamento de erro** (burn rate), em janelas curta e longa. É mais fiel ao impacto que um limiar fixo sobre a taxa de erro.
- Todo alerta tem dono e link de runbook. Alerta sem ação possível é ruído, e ruído treina a equipe a ignorar alertas.

### 2.4 Segurança operacional

- **Detecção:** pico de 401 e 403, saída de rede incomum, ação administrativa fora de horário, aumento de validações rejeitadas.
- **Integridade da auditoria:** armazenamento somente de anexação, acesso restrito e registro de quem consultou.
- **Segredos fora da telemetria.** Redija no collector e teste com fixtures que contêm padrões de segredo.
- **Minimização de dados.** A Lei Geral de Proteção de Dados (LGPD) exige que apenas o necessário seja coletado e mantido. Defina a retenção por classe de dado e valide com o jurídico.
- **O pipeline também é superfície de ataque.** O endpoint OTLP exige autenticação. Restrinja a rede onde for possível.

### 2.5 Manutenção

- Painel por serviço com anotação de deploy: versão e `feature.id`.
- Compare métricas antes e depois de cada deploy. A análise do canário usa as mesmas métricas do painel.
- Registre a versão das bibliotecas de telemetria. Atualizações de SDK podem mudar nomes de métricas.

### 2.6 Se o produto usa LLM

A convenção GenAI do OpenTelemetry tem estes elementos:

- **Spans:** `chat {modelo}`, `invoke_agent {agent.name}`, `execute_tool {tool.name}`.
- **Atributos:** `gen_ai.operation.name`, `gen_ai.provider.name`, `gen_ai.request.model`, `gen_ai.response.model`, `gen_ai.usage.input_tokens`, `gen_ai.usage.output_tokens`, `gen_ai.agent.name`, `gen_ai.conversation.id`.
- **Prompts e respostas** ficam em eventos, não em atributos de span, e a captura é opt-in. A especificação recomenda captura completa só em staging e pré-produção. Em produção, mantenha apenas metadados ou aplique redação antes de sair da infraestrutura.

**Atenção à estabilidade.** As convenções GenAI estão em estado de desenvolvimento, e os nomes podem mudar entre versões sem janela de depreciação. Fixe a versão da biblioteca e isole os nomes de atributos em uma camada de adaptação no código.

---

## 3. Correlação entre os dois planos

A cadeia que permite responder "quanto custou e o que quebrou nessa feature":

```
status.md (trace-id, feature.id)
   → OTEL_RESOURCE_ATTRIBUTES na sessão de agentes (feature.id)
   → commit e PR com o feature.id no título ou no corpo
   → deploy com anotação: feature.id, versão e commit
   → spans e métricas da aplicação com service.version
   → incidente registrado com o feature.id que o causou
```

Com essa cadeia, um painel mostra o custo da feature e os incidentes que ela causou, lado a lado.

---

## 4. Pipeline de coleta

Um **OpenTelemetry Collector** por ambiente recebe os dados dos agentes e da aplicação. Responsabilidades:

- **Autenticação** na entrada. Os desenvolvedores enviam por um gateway com credencial própria.
- **Redação**: remove `user.email` e pseudonimiza `user.account_uuid`.
- **Limitação de memória** para não derrubar o collector em pico.
- **Lotes** para reduzir o número de requisições ao backend.
- **Pipelines separados:** métricas, logs operacionais, logs de auditoria (retenção maior) e traces.

Exemplo de configuração em `templates/otel-collector.yaml`. Ajuste ao backend escolhido. A escolha da plataforma exige ADR do arquiteto.

---

## 5. Gates de observabilidade

Acrescente estes gates ao CI, além dos de `gates-metricas.md`:

| Gate | Como verificar | Bloqueia quando |
|---|---|---|
| Endpoint novo tem span e métrica | Teste que aciona o endpoint e lê o span e a métrica | Ausência de qualquer um |
| Logs sem dados pessoais nem segredos | Teste com fixtures e scanner de segredos | Padrão encontrado |
| Cardinalidade controlada | Lint que proíbe rótulos como `user_id`, `email` e caminhos brutos | Rótulo proibido |
| Alerta com dono e runbook | Validação dos arquivos de alerta | Campo ausente |
| Configuração de agentes segura | `scripts/gate-telemetria.sh` | Flag proibida ou credencial no repositório |

---

## 6. Anti-padrões

- `OTEL_LOG_RAW_API_BODIES` ligado em ambiente compartilhado.
- Variáveis `OTEL_*` no repositório, esperando que funcionem. Elas são ignoradas.
- Prompts ou respostas com dados pessoais em log.
- `user_id` ou e-mail como rótulo de métrica.
- Alertas sem dono.
- Observabilidade só dos agentes, ou só da aplicação. Os dois planos se complementam.
- Custo sem `feature.id`. Sem ele, o gasto não tem dono.
- Auditoria com a mesma retenção e o mesmo acesso dos logs de depuração.

---

## 7. Checklist de implantação

- [ ] Telemetria habilitada em configurações gerenciadas, não no repositório
- [ ] Prompts, respostas e corpos de API desligados
- [ ] `feature.id` exportado em cada sessão de feature
- [ ] Collector com autenticação, redação e pipeline de auditoria separado
- [ ] Painéis de custo por feature e de hit de cache publicados
- [ ] SLO definido para cada jornada da spec
- [ ] Alertas com dono e runbook
- [ ] Retenção por classe de dado validada com o jurídico
- [ ] `scripts/gate-telemetria.sh` rodando no CI
