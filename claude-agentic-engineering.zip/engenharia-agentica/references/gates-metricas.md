# Gates, métricas e ablação

## Gates

Um gate é um ponto em que a feature só avança se uma condição verificável for atendida. Há duas camadas, e só a primeira é garantia.

### Camada 1: remota e obrigatória

Configure branch protection para exigir, antes do merge:

| Gate | Ferramenta de exemplo | Bloqueia merge quando |
|---|---|---|
| Testes unitários e de aceitação | Comando de teste do projeto | Qualquer falha |
| Análise estática de segurança | semgrep | Achado de severidade alta ou crítica sem triagem |
| Dependências vulneráveis | osv-scanner, npm audit ou equivalente | Vulnerabilidade crítica sem aceite |
| Segredos no código | gitleaks | Qualquer detecção |
| Cobertura de regressão | Relatório de cobertura | Queda acima do limite definido na linha de base |
| Configuração de telemetria segura | `scripts/gate-telemetria.sh` | Flag que expõe prompts, respostas ou corpos de API, ou credencial de observabilidade no repositório |
| Endpoint novo instrumentado | Teste em staging que lê span e métrica | Ausência de span ou métrica do endpoint |

Essas ferramentas não dependem do comportamento do agente. Um agente que ignora a regra ainda não consegue fazer merge.

### Camada 2: local e de apoio

- **Hooks** podem bloquear o fim de um turno enquanto um teste falha. Ajudam o agente a não parar cedo, mas não substituem o CI.
- **Condições `/goal`** mantêm o agente trabalhando até um critério ser satisfeito em execuções longas.
- **Revisão em contexto novo** é um gate humano-agente: o revisor só aprova com "sem lacunas de correção".

### Gates humanos

| Gate | Quando | O humano confirma |
|---|---|---|
| H1 | Fim da spec | Critérios testáveis, escopo e fora de escopo |
| H2 | Decisão arquitetural marcada como irreversível | Alternativa escolhida e custo de reverter |
| H3 | Antes do deploy em produção | Resultado do canário e do plano de rollback |
| Aceite de risco | Achado de segurança que não será corrigido agora | Risco, prazo e responsável |

Gate humano sem leitura não é gate. Registre quem aprovou, quando e com base em quê, em `status.md`.

## Métricas

### Entrega (DORA)

- **Frequência de deploy:** deploys em produção por período.
- **Lead time para mudança:** do primeiro commit ou da aprovação da spec até o deploy.
- **Taxa de falha de mudança:** percentual de deploys que exigem correção ou rollback.
- **Tempo de restauração:** da detecção até a normalização.

Calcule a partir do CI e do histórico do git, com script. Não peça a um LLM para calcular.

### Específicas do time de agentes

| Métrica | Como calcular | Para que serve |
|---|---|---|
| First-pass rate | PRs que passam no CI sem retrabalho ÷ PRs abertos | Qualidade da primeira entrega |
| Custo por PR mergeado | Tokens convertidos em custo ÷ PRs mergeados | Eficiência econômica |
| Intervenções humanas por feature | Número de vezes que um humano precisou corrigir ou redirecionar | Autonomia real |
| Defeitos de escape | Bugs em produção atribuíveis a features do pipeline | Qualidade final |
| Falsos positivos de segurança | Achados de scanner classificados como falso positivo ÷ total | Ruído da triagem |
| Hit de cache | Porcentagem de entrada servida do cache, de `/usage` | Eficiência de tokens |
| Tokens por etapa | Soma por agente, de `status.md` | Onde está o gasto |

Registre cada feature em `status.md`. O script de métricas agrega esses dados por período.

### Interpretação

- **First-pass rate baixa com custo alto** indica spec ou contrato fracos. Antes de mudar os agentes, melhore a spec.
- **Defeitos de escape altos com first-pass alta** indicam testes de aceitação que não cobrem os critérios. Revise o QA.
- **Hit de cache baixo de forma recorrente** indica alterações frequentes no começo do prefixo. Veja `references/tokens.md`.
- **Muitas intervenções humanas** indicam que a classe da feature está subestimada ou que o techlead delega sem contrato.

## Ablação: decidir se um papel vale o custo

Um papel só se justifica por medição. Procedimento:

1. **Monte o conjunto de tarefas.** Escolha de 20 a 30 tickets passados, com resultado conhecido (o que foi entregue e quais defeitos apareceram).
2. **Defina a linha de base.** Rode o conjunto com a configuração atual e registre first-pass rate, custo por PR, intervenções e defeitos de escape.
3. **Remova um papel por vez.** Rode o conjunto sem o papel testado. Mantenha o restante igual.
4. **Compare.** O papel fica se melhora pelo menos uma métrica de qualidade de forma relevante e o custo adicional é aceitável para o valor entregue.
5. **Documente a decisão** em `reports/ablacao-<papel>-AAAA-MM.md`, com os números.

Defina os limiares de "relevante" e de "aceitável" com a equipe, a partir da linha de base. Não use valores genéricos.

Repita a ablação quando trocar de modelo. Um modelo mais capaz pode tornar um papel desnecessário, e isso só aparece na medição.

## Relatório de métricas

Um relatório mensal, gerado pelo script de métricas, deve conter:

- Métricas DORA com comparação com a linha de base
- Métricas de agentes por classe de feature
- Papéis em teste de ablação e o resultado
- Principais falhas, classificadas pelas categorias de falha de sistemas multiagente (especificação, coordenação, verificação)
- Ações decididas e responsáveis

O relatório informa a decisão. Quem decide é o humano.
