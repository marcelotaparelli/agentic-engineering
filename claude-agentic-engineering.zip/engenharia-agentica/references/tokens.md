# Otimização de tokens

Este playbook reúne as práticas para gastar tokens onde eles compram qualidade. Os números e regras de cache vêm da documentação oficial do Claude Code. Antes de aplicar uma configuração específica, confira a versão instalada com `claude --version`, porque o comportamento de cache e de custo muda entre versões.

## 1. Números de referência

- **Multiagente custa mais.** O sistema multiagente de pesquisa da Anthropic usou cerca de 4x os tokens de um chat em cada subagente e cerca de 15x no conjunto. Segundo a mesma análise, o uso de tokens explica cerca de 80% da variância de desempenho. Ou seja, o gasto compra desempenho, e o objetivo é gastar onde ele compra.
- **Agent teams em plan mode** consomem cerca de 7x os tokens de uma sessão padrão, segundo a documentação.
- **Referência de custo.** A documentação oficial informa média empresarial de cerca de US$ 13 por desenvolvedor por dia ativo, com 90% dos usuários abaixo de US$ 30. Use isso para calibrar a linha de base da sua equipe, não como meta.
- **Subagentes têm orçamento próprio.** As requisições de um subagente contam no mesmo limite da sessão principal.

## 2. Cache de prompt

### Modelo mental

Cada requisição é um **prefixo** que cresce: sistema e ferramentas, depois CLAUDE.md, depois a conversa. O cache reaproveita o trecho inicial idêntico ao da requisição anterior. Qualquer mudança no começo invalida tudo que vem depois. Por isso a ordem e a estabilidade do começo importam mais do que qualquer outra coisa.

### O que mantém o cache

- Editar arquivos do repositório. O Claude Code acrescenta um aviso ao final da conversa.
- Invocar skills e comandos. Eles entram como mensagens novas.
- Mudar o modo de permissão.
- Mudar o estilo de saída.
- `/recap` e `/rewind`.
- Criar subagentes. O pai não perde o cache; o subagente monta o próprio.

### O que invalida o cache (uma vez por mudança)

| Ação | Efeito | Como evitar |
|---|---|---|
| `/model` | Todo o histórico é relido sem cache | Escolha o modelo no início da etapa |
| Mudar effort | Todo o histórico é relido, exceto em Opus 5.5, Sonnet 5.5, Haiku 5.5 e Fable 5.1 com API key ou assinatura | Defina o effort no início; use `/effort` entre etapas |
| Ligar fast mode | Uma releitura, cobrada a taxa do fast mode | Ligue no começo da sessão, não no meio |
| Conectar ou remover MCP sem tool search | Definições de ferramenta mudam | Mantenha tool search ativo e ajuste MCP entre features |
| Negar uma ferramenta inteira (regra sem escopo, como `Bash`) | Definição removida do prefixo, se tool search estiver indisponível | Use regras com escopo, como `Bash(rm *)`, que não alteram o prefixo |
| `/compact` | Histórico reescrito | Use em fronteira de etapa, não no meio de um teste |
| Muitas imagens | Histórico reprocessado a partir da primeira imagem removida | Compartilhe imagens só quando necessário |
| Atualizar o Claude Code | Prompt do sistema muda | Atualize entre features |

### Regras práticas

- **Congele o começo.** Escolha modelo, effort e conjunto de MCP no início da etapa e mantenha.
- **CLAUDE.md não se atualiza no meio da sessão.** A edição só vale após `/clear`, `/compact` ou reinício. Faça mudanças de contexto entre features.
- **TTL padrão de 5 minutos.** A sessão principal em assinatura, dentro do plano, recebe 1 hora. Subagentes recebem 5 minutos por padrão.
- **Para fleets que esperam**, defina `subagentPromptCacheTtl` como `1h`. Para API key ou nuvem, defina `promptCacheTtl` como `1h`.
- **Pausa maior que o TTL** causa um primeiro turno frio. Ao voltar de uma pausa longa, prefira `/clear` com um `status.md` do que arrastar um histórico velho.
- **Meça.** `/usage` mostra a linha `Prompt cache (main)`, com a porcentagem de entrada vinda do cache e a causa provável do último miss.

## 3. Contexto

- **`/clear` entre features** tem custo zero. Antes, use `/rename` para poder retomar a sessão depois com `/resume`.
- **`/compact` com foco.** Exemplo: `/compact preserve caminhos alterados, comandos de teste, decisões de ADR e o estado do status.md`.
- **Memória de trabalho em arquivo.** `spec.md`, ADRs e `status.md` guardam o estado. Assim, `/clear` não perde nada.
- **`/btw` para perguntas rápidas.** A resposta não entra no histórico.
- **Leitura cirúrgica.** Use Grep antes de Read. Leia com `offset` e `limit`. Nunca peça "investigue o sistema".
- **Não cole saídas longas no chat.** Aponte o arquivo. Uma linha com o caminho custa menos que mil linhas de log.

## 4. Delegação e contrato de saída

A forma da delegação decide quanto contexto o subagente carrega e quanto volta.

**Ruim:**

> Veja este código de autenticação [cola 400 linhas] e estes testes [cola 300 linhas] e corrija o bug de sessão.

**Bom:**

> Tarefa: corrigir expiração de sessão, critério AC-03 da spec.
> Entradas: `docs/features/login/spec.md`, `src/auth/session.ts`.
> Arquivos permitidos: `src/auth/session.ts` e `tests/auth/session.test.ts`.
> Critério: o teste AC-03 passa e nenhum outro teste quebra.
> Resposta: no máximo 15 linhas, com arquivos alterados e resultado do teste.

A versão boa passa caminhos, delimita o escopo e fixa o formato de saída. Em `maxTurns`, defina um teto de turnos por subagente para evitar exploração sem fim.

## 5. Modelo e effort por tarefa

| Tarefa | Modelo | Effort |
|---|---|---|
| Triagem, coleta de métricas, resumos | haiku | baixo |
| Busca e exploração de código | haiku | baixo |
| Implementação, testes, revisão | sonnet | médio |
| Decisão de arquitetura, plano, resolução de conflito | opus | alto |
| Threat model | sonnet, ou opus em superfície complexa | médio ou alto |

Três observações:

- Para trocar o modelo do subagente Explore, crie `.claude/agents/explore.md` com `model: haiku`. Ele sobrescreve o padrão.
- Os modelos Opus 5.5, Sonnet 5.5, Haiku 5.5 e Fable 5.1 sempre usam pensamento estendido. Reduza com effort, não desligando o pensamento.
- `MAX_THINKING_TOKENS` só se aplica a modelos com orçamento fixo de pensamento. Em modelos adaptativos, ele é ignorado.

## 6. Ferramentas e servidores MCP

- **Restrinja ferramentas por papel.** Cada definição ocupa contexto. O revisor não precisa de Edit. O techlead não precisa de Write.
- **MCP só o que a etapa usa.** Em `/mcp`, desative o restante. Ferramentas diferidas (tool search) são o padrão e preservam o cache.
- **CLI quando existir.** `gh`, `aws` e similares costumam custar menos que um servidor MCP equivalente, porque não adicionam listas de ferramentas.
- **Inteligência de código (LSP)** em linguagens tipadas reduz leituras exploratórias. Uma chamada de "ir para definição" substitui uma busca seguida de várias leituras.

## 7. Filtrar saídas com hooks

Saídas longas são a maior fonte de desperdício. Um hook `PreToolUse` pode reduzir uma saída de teste de milhares de linhas para algumas dezenas, mostrando só as falhas. A documentação do Claude Code traz um exemplo completo: um script que detecta comandos de teste e acrescenta `grep` para `FAIL`, `ERROR` e `error:`, limitado a 100 linhas. O mesmo padrão serve para logs, com `grep ERROR` antes de qualquer leitura.

Configure no `settings.json` do projeto e confirme com `/hooks`.

## 8. Paralelismo: quando vale

Paralelizar multiplica o gasto. Só vale quando reduz tempo sem multiplicar contexto desnecessário:

- **Vale:** pesquisa em fatias independentes; engenheiros em módulos separados, cada um em worktree; revisão com lentes diferentes (segurança, performance, cobertura).
- **Não vale:** tarefas sequenciais, tarefas com muitas dependências entre si e tarefas que exigem o mesmo contexto compartilhado. O próprio material da Anthropic indica que multiagente não se encaixa bem nesses casos.

## 9. Orçamento e automação

- **Teto por feature** em `status.md`, definido pela classe (trivial, pequena, média ou grande).
- **Alerta em 70% do teto** e decisão humana ao ultrapassar 100%.
- **Em CI**, use `claude -p "<tarefa>" --output-format json --max-budget-usd <valor>`. Para execuções descartáveis, acrescente `--no-session-persistence`.
- **Permissões restritas em CI:** `--permission-mode dontAsk` com `--allowedTools` listando só o necessário. Ações fora da lista são negadas sem travar a execução.

## 10. Checklist por feature

- [ ] Classe definida e teto de tokens registrado em `status.md`
- [ ] Modelo e effort escolhidos por etapa
- [ ] Delegações por caminho, com contrato de saída de até 15 linhas
- [ ] Nenhum MCP ou ferramenta trocado no meio de uma etapa
- [ ] Filtros de saída ativos para testes e logs
- [ ] `/clear` entre features e `/compact` apenas em fronteira de etapa
- [ ] Cache verificado em `/usage` ao fim da feature
- [ ] Consumo e causas de miss registrados em `status.md`
