#!/usr/bin/env bash
# Gate de configuração de telemetria. Falha se o repositório contém configuração
# insegura de OpenTelemetry ou credenciais de observabilidade.
# Uso: scripts/gate-telemetria.sh [diretório-do-repositório]
set -uo pipefail

ROOT="${1:-.}"
cd "$ROOT" || { echo "diretório não encontrado: $ROOT" >&2; exit 2; }

EXCLUDES=(--exclude-dir=.git --exclude-dir=node_modules --exclude-dir=docs --exclude-dir=references)
fail=0

# 1. Flags que expõem conteúdo sensível, em qualquer arquivo versionado.
# Só casa quando a flag está ligada (1, true ou file:...). Valor 0 não é flag ligada.
SENSITIVE='OTEL_LOG_(RAW_API_BODIES|TOOL_CONTENT|USER_PROMPTS|ASSISTANT_RESPONSES|MANAGED_SETTINGS)"?[[:space:]]*[:=][[:space:]]*"?(1|true|file:)'
if matches=$(grep -rEn "${EXCLUDES[@]}" -e "$SENSITIVE" . 2>/dev/null); then
  echo "FALHA: flag que expõe conteúdo sensível:"
  echo "$matches"
  fail=1
fi

# 2. Credenciais de observabilidade escritas no código.
if matches=$(grep -rEn "${EXCLUDES[@]}" -e 'Authorization=Bearer [A-Za-z0-9._-]{8,}' -e 'Authorization"?[[:space:]]*:[[:space:]]*"Bearer [A-Za-z0-9._-]{8,}' . 2>/dev/null); then
  echo "FALHA: credencial de observabilidade no repositório:"
  echo "$matches"
  fail=1
fi

# 3. Variáveis OTEL_* em configuração de projeto são ignoradas pelo Claude Code.
for f in .claude/settings.json .claude/settings.local.json; do
  if [[ -f "$f" ]] && grep -q 'OTEL_' "$f"; then
    echo "AVISO: $f define OTEL_*. Essas variáveis são ignoradas no nível do projeto."
    echo "       Mova para configurações gerenciadas, shell ou ~/.claude/settings.json."
  fi
done

if [[ $fail -eq 0 ]]; then
  echo "OK: configuração de telemetria sem problemas bloqueantes."
  exit 0
fi
exit 1
