#!/usr/bin/env bash
# Cria a estrutura de uma feature em docs/features/<id>/ a partir dos templates da skill.
# Uso: scripts/novo-feature.sh <id-em-kebab-case>
set -euo pipefail

ID="${1:-}"
if [[ ! "$ID" =~ ^[a-z0-9][a-z0-9-]{1,40}$ ]]; then
  echo "uso: $0 <id-em-kebab-case>   (ex.: login-google)" >&2
  exit 1
fi

SKILL_DIR="$(cd "$(dirname "$0")/.." && pwd)"
DEST="docs/features/$ID"

if [[ -e "$DEST" ]]; then
  echo "já existe: $DEST" >&2
  exit 1
fi

mkdir -p "$DEST/adr" "$DEST/contratos" "$DEST/reports"

TRACE="$(date +%Y%m%d%H%M%S)-$(head -c 4 /dev/urandom | od -An -tx1 | tr -d ' \n')"

sed -e "s/<id>/$ID/g" -e "s/<trace-id>/$TRACE/g" \
  "$SKILL_DIR/templates/status.md" > "$DEST/status.md"

sed -e "s/<id>/$ID/g" "$SKILL_DIR/templates/spec.md" > "$DEST/spec.md"

echo "feature criada: $DEST"
echo "trace: $TRACE"
echo "próximo passo: preencher $DEST/spec.md e pedir aprovação humana (H1)"
