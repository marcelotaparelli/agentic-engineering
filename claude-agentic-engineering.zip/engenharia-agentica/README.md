# Engenharia agêntica

Skill para o Claude Code que monta e opera uma equipe de agentes cobrindo o ciclo completo de desenvolvimento de software: requisito, design, testes, implementação, verificação, deploy e operação.

A unidade de entrega é um **artefato verificado**, não uma conversa entre agentes. Cada etapa tem um contrato escrito, uma evidência, e um portão humano nos pontos irreversíveis.

O detalhamento completo está em `SKILL.md`. Este arquivo é o guia de uso.

---

## O que você recebe

| Parte | Função |
|---|---|
| Nove agentes em `templates/agente-*.md` | Techlead, arquiteto, engenheiro, QA, revisor, segurança, crítico, atacante e observabilidade |
| Artefatos de feature em `templates/` | `spec.md` e `status.md`, que guardam o estado da feature |
| Telemetria em `templates/` | Configuração segura do OpenTelemetry e um collector de exemplo |
| Scripts em `scripts/` | Abertura de feature e gate de telemetria |
| Referências em `references/` | Contrato de cada papel, playbook de tokens, gates e métricas, observabilidade |

**Ainda não incluído:** agentes de Produto e DevOps. O contrato deles existe em `references/papeis.md`, mas não há template. Até criá-los, o techlead escreve a spec como rascunho, e o deploy é feito sob sua aprovação (H3).

---

## Instalação

Descompacte a skill em um destes lugares:

- **Por projeto:** `.claude/skills/engenharia-agentica/`, dentro do repositório.
- **Global:** `~/.claude/skills/engenharia-agentica/`, para usar em todos os projetos.

Depois, a partir da raiz do projeto, instale os agentes:

```bash
SKILL=.claude/skills/engenharia-agentica   # ou ~/.claude/skills/engenharia-agentica
mkdir -p .claude/agents
for f in "$SKILL"/templates/agente-*.md; do
  cp "$f" ".claude/agents/$(basename "$f" | sed 's/^agente-//')"
done
ls .claude/agents/
```

Você deve ver `techlead.md`, `arquiteto.md`, `engenheiro.md`, `qa.md`, `revisor.md`, `seguranca.md`, `critico.md`, `atacante.md` e `observabilidade.md`.

---

## Antes da primeira feature

Esta etapa é feita uma vez. Pule qualquer item e o processo perde a garantia que oferece.

1. **Telemetria fora do repositório.** Use `templates/managed-settings-otel.json` em configurações gerenciadas ou no shell. Variáveis `OTEL_*` em `.claude/settings.json` são ignoradas pelo Claude Code.
2. **Permissões de segurança.** Em `.claude/settings.json`, adicione `permissions.deny` para os hosts de produção. A restrição de escopo do atacante é uma instrução, e esta regra é a proteção real.
3. **Barreira de CI.** Configure branch protection exigindo testes, semgrep, gitleaks, osv-scanner e `scripts/gate-telemetria.sh`. Esta é a única barreira que não depende do comportamento do agente.
4. **Escolha um piloto.** Uma feature real, de classe pequena e baixo risco. Ela serve para calibrar o processo.

---

## Uso no dia a dia

### 1. Abrir a feature

```bash
.claude/skills/engenharia-agentica/scripts/novo-feature.sh login-google
```

O script cria `docs/features/login-google/` com `spec.md`, `status.md` e as pastas `adr/`, `contratos/` e `reports/`. Ele também imprime a variável de telemetria. Para incluir o time, defina `TEAM_ID` antes do comando.

Exporte a variável e abra o techlead:

```bash
export OTEL_RESOURCE_ATTRIBUTES="feature.id=login-google,team.id=plataforma"
claude --agent techlead
```

### 2. Escrever a spec e aprovar em H1

Peça ao techlead, por exemplo:

> Feature login-google, classe pequena. Escreva a spec em `docs/features/login-google/spec.md` a partir do template, com critérios AC-01 e seguintes, testáveis, e fora de escopo explícito. Pare em H1.

Leia os critérios. Pergunte para cada um: "um teste automatizado consegue verificar isso?" Se não, peça correção. Este é o portão com maior retorno do seu tempo.

### 3. Design

Em feature média ou grande, o techlead delega ao arquiteto, e em paralelo ao crítico e ao atacante. Leia os três relatórios antes de decidir. Se houver decisão irreversível, ela chega a você em **H2**, com o custo de reverter.

### 4. Testes primeiro

O QA escreve os testes de aceitação e confirma que eles falham antes da implementação. Teste que passa sem código está errado.

### 5. Implementação

O engenheiro trabalha em worktree isolado, módulo por módulo. Ele não altera teste de aceitação. Se um teste parecer errado, reporta.

### 6. Verificação

O revisor lê o diff em contexto novo e gera `review.md`. O atacante roda no staging e gera `ataque.md`. Você só aceita quando o CI estiver verde e o `review.md` disser "sem lacunas de correção".

### 7. Deploy

Só com **H3**, sua aprovação explícita, depois de ver o resultado do canário.

### 8. Fechar

O techlead atualiza `status.md` com tokens, evidências e retrospectiva. Depois, `/clear` antes da próxima feature.

---

## Tamanho da feature

| Classe | Quando | Agentes |
|---|---|---|
| Trivial | Uma mudança, descrita em uma frase | Nenhum. Execução direta com uma verificação |
| Pequena | Um módulo, sem decisão de arquitetura | Engenheiro e revisor |
| Média | Mais de um módulo, ou toca testes de regressão | Inclui QA. Segurança se houver autenticação, dados, entrada externa ou dependência nova. Crítico e atacante |
| Grande | Decisão de arquitetura ou superfície nova | Pipeline completo, com arquiteto e threat model |

Classificar errado custa caro nos dois sentidos. Feature grande tratada como pequena passa sem revisão de arquitetura. Pequena tratada como grande gasta tokens sem ganho.

---

## Papéis que decidem e papéis que contestam

Três princípios sustentam a equipe:

- **Quem escreve não avalia.** Revisor, QA, crítico e atacante são agentes separados do autor.
- **Ninguém aprova sozinho.** O techlead coordena e decide as etapas. As irreversíveis passam por você.
- **Recomendar e provar, não corrigir.** O crítico e o atacante não editam código. Eles entregam achado, prova e proteção. Quem corrige é o engenheiro, e quem aprova é você.

O **crítico** questiona cada decisão relevante: por que foi escolhida, quais alternativas existiram, quanto custa, quais as implicações de reverter. Ele não bloqueia nada, e toda objeção vem com alternativa e custo.

O **atacante** busca falhas em todas as etapas, do requisito à operação, sempre em staging e com dados de teste. Cada achado confirmado vira teste de regressão em `tests/seguranca/`.

---

## Rotina

| Quando | O que fazer |
|---|---|
| Em cada feature | Abrir, aprovar a spec (H1), revisar os relatórios de design, aprovar H2 e H3 quando aplicável, conferir `status.md` |
| Depois de cada feature | Registrar tokens e intervenções. Atualizar a retrospectiva |
| Mensal | Rodar o crítico sobre ADRs recentes e alertas de custo. Rodar o atacante sobre o sistema inteiro. Gerar o relatório de métricas |
| A cada 20 a 30 tickets | Ablação: testar se cada papel melhora a qualidade o suficiente para justificar o custo |

---

## Controle de tokens

- **Uma feature por sessão.** Use `/clear` entre features. O estado fica nos arquivos.
- **Não troque modelo, effort nem ferramentas no meio de uma etapa.** Cada troca invalida o cache.
- **Delegue por caminho.** Cole o conteúdo nunca. "Leia `spec.md`" custa menos que colar a spec.
- **`/compact` só na fronteira entre etapas**, com foco explícito.
- **`/usage` mostra o cache.** Hit baixo quase sempre significa que o começo do contexto mudou.
- **Teto por feature** em `status.md`. Ao chegar a 100%, decida: continuar, reduzir escopo ou parar.

Detalhes no playbook: `references/tokens.md`.

---

## Sinais de problema

| Sinal | Causa provável | O que fazer |
|---|---|---|
| Você corrige o agente a cada etapa | Spec ou contrato fraco | Melhore a spec antes de delegar de novo |
| "Pronto" sem evidência | Techlead aceitando sem verificar | Peça a saída do teste ou o `review.md` |
| Crítico com dez achados sem alternativa | Prompt sem limite | Peça só os três mais importantes, com alternativa |
| Atacante repetindo o mesmo achado | Parada sem critério | Confira o limite de turnos e o contrato |
| Custo alto sem entrega | Muitos subagentes em tarefa simples | Reclassifique a feature para menos agentes |
| Teste passa sem código | Teste copia o comportamento atual | Reescreva o teste a partir da spec |

---

## Limites conhecidos

- **Piloto ainda não rodado de ponta a ponta.** Trate a primeira feature como teste do processo. Ajuste os templates com o que aparecer.
- **Nomes de alguns eventos de telemetria** (`agent_id`, `subagent_completed`, `start_type` e outros) ainda precisam de confirmação com `claude --debug-file`. Estão marcados em `references/observabilidade.md`.
- **Atacante e crítico dependem de disciplina de escopo.** Sem `permissions.deny` e sem a barreira de CI, a restrição é só uma instrução.
- **Custos são estimativas.** Calibre a linha de base da sua equipe antes de definir tetos.

---

## Arquivos

```
engenharia-agentica/
├── SKILL.md                      # Visão geral, pipeline, princípios, anti-padrões
├── README.md                     # Este guia
├── references/
│   ├── papeis.md                 # Contrato de cada papel
│   ├── tokens.md                 # Playbook de otimização de tokens
│   ├── gates-metricas.md         # Gates, métricas DORA, métricas de agentes, ablação
│   └── observabilidade.md        # Telemetria em dois planos
├── templates/
│   ├── agente-*.md               # Definições dos agentes
│   ├── spec.md                   # Especificação da feature
│   ├── status.md                 # Estado, decisões, consumo e retrospectiva
│   ├── managed-settings-otel.json
│   └── otel-collector.yaml
└── scripts/
    ├── novo-feature.sh           # Cria a estrutura de uma feature
    └── gate-telemetria.sh        # Bloqueia flags de conteúdo sensível no CI
```
</content>
