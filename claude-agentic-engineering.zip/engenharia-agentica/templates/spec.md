# Spec: <título da feature>

- **ID:** <id>
- **Classe:** trivial | pequena | média | grande
- **Status:** rascunho | aprovada por humano em AAAA-MM-DD por <nome>

## Problema

Descreva o problema do ponto de vista do usuário, em três ou quatro frases.

## Objetivo

O que a feature entrega, em uma frase.

## Não objetivos

O que esta feature deliberadamente não faz.

## Usuários e cenários

- Cenário principal:
- Cenários secundários:

## Critérios de aceitação

Cada critério deve ser testável. Use o formato Dado/Quando/Então e numere como AC-01, AC-02...

- **AC-01:** Dado <contexto>, quando <ação>, então <resultado observável>.
- **AC-02:** Dado <contexto>, quando <ação>, então <resultado observável>.

## Requisitos não funcionais

- Desempenho:
- Disponibilidade:
- Privacidade e dados pessoais:
- Custo operacional:

## Dependências e contratos

- Serviços, APIs e dados de que a feature depende:
- Contratos que serão criados ou alterados:

## Verificação de ponta a ponta

Passos para verificar a feature no ambiente de staging, do início ao fim, com o resultado esperado.

## Fora de escopo

- Itens que podem parecer parte da feature, mas não são.

## Riscos conhecidos

| Risco | Probabilidade | Impacto | Mitigação |
|---|---|---|---|
| | | | |
