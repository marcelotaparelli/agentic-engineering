# Status: <id>

- **Classe:**
- **Teto de tokens da feature:**
- **Trace ID:** <trace-id>
- **Última atualização:**

## Etapas

| Etapa | Agente | Estado | Evidência | Tokens |
|---|---|---|---|---|
| Spec | produto | pendente | | |
| Design (ADR) | arquiteto | pendente | | |
| Threat model | segurança | pendente | | |
| Testes de aceitação | qa | pendente | | |
| Implementação | engenheiro | pendente | | |
| Verificação | qa, revisor, segurança | pendente | | |
| Deploy | devops | pendente | | |
| Operação | observabilidade | pendente | | |

Estados válidos: pendente, em andamento, aceita, rejeitada, aguardando humano.

## Decisões humanas

- **H1 (spec):** pendente
- **H2 (irreversível):** não se aplica
- **H3 (produção):** pendente
- **Aceite de risco:** nenhum

## Consumo

- **Total de tokens:**
- **Hit de cache (de /usage):**
- **Intervenções humanas:** 0
- **Lacunas abertas:**

## Retrospectiva

- **O que funcionou:**
- **O que falhou:** (categorize: especificação, coordenação ou verificação)
- **Mudança para a próxima feature:**
