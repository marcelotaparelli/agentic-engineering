---
name: engenharia-agentica
description: Projeta, monta e opera uma equipe de agentes de IA para o ciclo completo de desenvolvimento de software (techlead, arquiteto, engenheiro, QA, segurança, revisor, DevOps, observabilidade e métricas) no Claude Code. Usa pipeline com gates, artefatos versionados no repositório, verificação independente e otimização de tokens. Acione quando o usuário pedir uma equipe ou time de agentes, multiagente, orquestração de subagentes, pipeline agêntico, fluxo de desenvolvimento com IA, ou quiser reduzir custo e consumo de tokens de agentes.
---

# Engenharia agêntica

Esta skill descreve e opera uma equipe de agentes que cobre o desenvolvimento de software do requisito à operação. A unidade de entrega é um **artefato verificado**, não uma conversa entre agentes.

## Quando usar

- Montar ou revisar uma equipe de agentes: papéis, pipeline, permissões e gates.
- Executar uma feature pelo pipeline completo ou por parte dele.
- Reduzir custo ou consumo de tokens de um fluxo agêntico existente.
- Decidir se um problema justifica multiagente ou se basta um agente bem configurado.

Não use para tarefas triviais de uma linha. Pipeline para mudança trivial é desperdício.

## Princípios

1. **Papel é contrato.** Cada agente tem entrada, saída e critério de aceite escritos em arquivo.
2. **Verificação determinística decide; LLM interpreta.** Testes, SAST, SCA, detecção de segredos e SLOs são a barreira. Agentes explicam o resultado.
3. **Quem escreve não avalia.** Revisão e QA rodam em contexto separado do autor.
4. **Techlead orquestra e não escreve código de produção.** Ele não recebe ferramentas de edição.
5. **Humano aprova os gates irreversíveis:** spec (H1), decisão irreversível (H2), produção (H3) e aceite de risco.
6. **Esforço proporcional.** A triagem decide quantos agentes entram. Trivial não passa pelo pipeline.
7. **Comunicação por arquivo no repositório**, não por chat entre agentes. Arquivos sobrevivem a `/clear` e a retomadas.
8. **Token é orçamento.** Cada feature tem teto, cada delegação tem contrato de saída curto, e cada tarefa usa o menor modelo que dá conta.
9. **Papel só fica se a medição mostrar ganho líquido** em qualidade por custo.

## Arquitetura

| Papel | Agente | Modelo | Entrega | Gate |
|---|---|---|---|---|
| Techlead | Sessão principal (`claude --agent techlead`) | opus | Plano, status, decisões | H1 aprova a spec |
| Produto | Subagente ou techlead | sonnet | `spec.md` com critérios Dado/Quando/Então | H1 |
| Arquiteto | Subagente | opus | ADR e contratos | H2 se irreversível |
| Segurança | Subagente com scanners | sonnet | Threat model e triagem | Sem crítico sem aceite |
| Engenheiro | Subagente por módulo, em worktree | sonnet | Código e testes unitários | Testes passam |
| QA | Subagente | sonnet | Testes de aceitação e plano de teste | Falham antes, passam depois |
| Revisor | Subagente em contexto novo | sonnet | `review.md` | Sem lacuna de correção |
| DevOps | Subagente sem acesso a produção | sonnet | Pipeline, IaC, canário | H3 aprova produção |
| Observabilidade | Subagente | sonnet | Telemetria da aplicação (traces, métricas, logs de auditoria), SLOs, alertas e custo dos agentes | Telemetria verificada em staging |
| Métricas | Script determinístico + resumo | haiku | Relatório DORA e de agentes | Informativo |

Detalhes de cada papel: `references/papeis.md`.

## Pipeline

```
Triagem → Spec → Design → Testes primeiro → Implementação → Verificação → Deploy → Operação
             H1       H2 (se irreversível)                                  H3
```

**Triagem decide o escopo:**

| Classe | Critério | Agentes |
|---|---|---|
| Trivial | Uma mudança fácil de descrever em uma frase | Nenhum. Execução direta com uma verificação |
| Pequena | Um módulo, sem decisão arquitetural | Engenheiro + revisor |
| Média | Mais de um módulo ou toca testes de regressão | + QA. + Segurança se houver auth, dados, entrada externa ou dependência nova |
| Grande | Decisão arquitetural ou superfície nova | Pipeline completo, com arquiteto e threat model |

## Procedimento do techlead

1. Abrir a feature: `scripts/novo-feature.sh <id>` cria `docs/features/<id>/` a partir dos templates.
2. Classificar a feature e registrar classe e teto de tokens em `status.md`.
3. Produzir a spec a partir de `templates/spec.md` e parar em **H1** até o humano aprovar.
4. Delegar cada etapa com contrato: objetivo, arquivos permitidos, critérios de aceite, caminhos de entrada e formato de saída de no máximo 15 linhas.
5. Aceitar uma etapa só com evidência anexada: saída de teste, relatório ou scan.
6. Atualizar `status.md` com estado, evidência e consumo de tokens ao fim de cada etapa.
7. Ao fechar, registrar métricas da feature e a retrospectiva.

## Otimização de tokens

Resumo. O playbook completo, com regras de cache, está em `references/tokens.md`.

- **Multiagente custa várias vezes mais que um agente.** Use-o quando a etapa for paralelizável ou precisar de contexto isolado. A própria Anthropic relata cerca de 15x os tokens de um chat no seu sistema multiagente.
- **Não troque modelo, effort, MCP ou ferramentas no meio de uma etapa.** Cada troca invalida o cache de prompt.
- **Delegue por referência.** Passe caminhos de arquivo e critérios, não conteúdo colado.
- **Contrato de saída curto.** O subagente devolve um resumo estruturado, nunca logs brutos.
- **Modelo por tarefa.** Opus decide, Sonnet implementa e revisa, Haiku coleta, triagem e resume.
- **`/clear` entre features** (custo zero). **`/compact` só em fronteira de etapa**, com instrução de foco.
- **Limites duros.** `maxTurns` em cada subagente. `--max-budget-usd` em execuções de CI.
- **Filtre saídas grandes** com hooks, como testes que mostram só falhas.

## Gates

Duas camadas:

- **Remota e obrigatória:** CI com branch protection. Merge só com testes, SAST, SCA e detecção de segredos verdes.
- **Local e de apoio:** hooks e condições `/goal` evitam que o agente pare antes da hora. Não são a barreira de segurança.

Detalhes, métricas DORA, métricas de agente e procedimento de ablação: `references/gates-metricas.md`.

## Anti-padrões

- Agentes conversando em malha, sem contrato de entrada e saída.
- O mesmo agente escreve o código e aprova.
- Credencial de produção dada a um agente.
- Spec aprovada sem leitura humana.
- Todos os agentes em Opus.
- Agent teams para todas as tarefas. A documentação indica cerca de 7x os tokens de uma sessão padrão quando os teammates rodam em plan mode.
- Sem ID de correlação. Sem ele, uma falha vira um resultado ruim sem histórico.
- Telemetria com prompts, respostas ou corpos de API ligados em ambiente compartilhado. Esses dados podem conter código sensível e dados pessoais.
- `OTEL_*` no `.claude/settings.json` do repositório, na expectativa de que a exportação funcione. O Claude Code ignora essas variáveis nesse nível.
- Confiar em "parece pronto" sem evidência.

## Arquivos desta skill

- `references/papeis.md`: contrato de cada papel, incluindo DevOps, Observabilidade e Métricas.
- `references/tokens.md`: playbook de otimização, regras de cache e checklist por feature.
- `references/gates-metricas.md`: gates, métricas e ablação.
- `references/observabilidade.md`: telemetria em dois planos. O gasto dos agentes (OpenTelemetry do Claude Code, custo por feature e alertas) e a telemetria da aplicação (traces, métricas, logs de auditoria, SLOs e segurança).
- `templates/spec.md` e `templates/status.md`: artefatos de feature.
- `templates/agente-*.md`: definições prontas para copiar em `.claude/agents/`, sem o prefixo `agente-` no nome do arquivo.
- `templates/managed-settings-otel.json`: variáveis de telemetria seguras por padrão, para configurações gerenciadas.
- `templates/otel-collector.yaml`: collector com redação de dados pessoais e pipelines separados.
- `scripts/novo-feature.sh`: cria a estrutura de uma feature.
- `scripts/gate-telemetria.sh`: bloqueia no CI flags que expõem conteúdo e credenciais de observabilidade no repositório.

Para instalar os agentes no projeto:

```bash
mkdir -p .claude/agents
for f in templates/agente-*.md; do
  cp "$f" ".claude/agents/$(basename "$f" | sed 's/^agente-//')"
done
```
