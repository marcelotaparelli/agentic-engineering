import importlib.util
import tempfile
import unittest
from pathlib import Path

spec = importlib.util.spec_from_file_location('agentic_install', Path(__file__).resolve().parents[1] / 'install.py')
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)


class InstallerTests(unittest.TestCase):
    def test_dry_run_has_no_side_effects(self):
        with tempfile.TemporaryDirectory() as tmp:
            repo = Path(tmp)
            (repo / '.git').mkdir()
            self.assertEqual(module.main(['--repo', str(repo), '--dry-run']), 0)
            self.assertFalse((repo / '.codex').exists())

    def test_conflict_requires_opt_in_then_backup(self):
        with tempfile.TemporaryDirectory() as tmp:
            repo = Path(tmp)
            (repo / '.git').mkdir()
            self.assertEqual(module.main(['--repo', str(repo)]), 0)
            existing = repo / '.codex/agents/architect.toml'
            existing.write_text('existing custom role', encoding='utf-8')
            self.assertEqual(module.main(['--repo', str(repo)]), 1)
            self.assertEqual(existing.read_text(encoding='utf-8'), 'existing custom role')
            self.assertEqual(module.main(['--repo', str(repo), '--update']), 0)
            self.assertNotEqual(existing.read_text(encoding='utf-8'), 'existing custom role')
            self.assertEqual(len(list((repo / '.agentic-backups').glob('*/.codex/agents/architect.toml'))), 1)
            self.assertFalse((repo / 'AGENTS.md').exists())
            self.assertFalse((repo / '.codex/config.toml').exists())

    def test_symlink_refused(self):
        with tempfile.TemporaryDirectory() as tmp:
            repo = Path(tmp) / 'repo'
            repo.mkdir()
            (repo / '.git').mkdir()
            external = Path(tmp) / 'external'
            external.mkdir()
            (repo / '.codex').symlink_to(external, target_is_directory=True)
            self.assertEqual(module.main(['--repo', str(repo)]), 2)
            self.assertEqual(list(external.iterdir()), [])


if __name__ == '__main__':
    unittest.main()
