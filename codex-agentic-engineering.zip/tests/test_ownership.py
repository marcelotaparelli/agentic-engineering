import unittest
from pathlib import Path
import tomllib

ROOT=Path(__file__).resolve().parents[1]
S=ROOT/'.agents/skills/agentic-engineering-team'

class OwnershipTests(unittest.TestCase):
    def test_mentor_role(self):
        p=tomllib.loads((ROOT/'.codex/agents/technical_ownership_mentor.toml').read_text())
        self.assertEqual(p['name'],'technical_ownership_mentor')
        self.assertIn('não',p['developer_instructions'].lower())

    def test_ownership_references_and_modes(self):
        content=(S/'references/technical-ownership.md').read_text()
        for term in ('passive | guided | deep', 'unreviewed', 'verified', 'path:line', 'não verificado'):
            self.assertIn(term,content)
        for filename in ('references/technical-ownership.md','assets/ownership-card.md','assets/ownership-ledger.md'):
            self.assertIn(filename,(S/'SKILL.md').read_text())
            self.assertTrue((S/filename).is_file())

    def test_no_auto_certification_of_knowledge(self):
        ledger=(S/'assets/ownership-ledger.md').read_text()
        self.assertIn('Não guardar prompts integrais',ledger)
        self.assertIn('explicação enviada pelo agente', ledger)
        self.assertIn('commit_sha',ledger)

    def test_readme_and_cockpit(self):
        readme=(ROOT/'README.md').read_text()
        self.assertIn('### G — Revisar o que os agentes construíram',readme)
        self.assertIn('## 12. Technical Ownership',readme)
        self.assertIn('technical_ownership_mentor',(S/'references/engineering-cockpit.md').read_text() if False else (S/'references/roles.md').read_text())
        self.assertIn('ownership_record',(S/'references/engineering-cockpit.md').read_text())

if __name__=='__main__': unittest.main()
