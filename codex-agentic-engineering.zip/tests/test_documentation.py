import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SKILL = ROOT/'.agents/skills/agentic-engineering-team'

class DocumentationTests(unittest.TestCase):
    def test_readme_copied_inside_skill(self):
        self.assertEqual((ROOT/'README.md').read_text(), (SKILL/'README.md').read_text())

    def test_new_app_and_cockpit_prompts(self):
        doc=(ROOT/'README.md').read_text()
        for key in ['### A — Aplicação nova', '### B — Arquitetura aprovada',
                    '### C — Projeto existente', '### D — Trabalho diário',
                    '### E — Revisão de release', '### F — Quando for implementar o cockpit']:
            self.assertIn(key,doc)

    def test_skill_references_exist(self):
        body=(SKILL/'SKILL.md').read_text()
        for rel in ['references/engineering-cockpit.md','assets/cockpit-scorecard.md']:
            self.assertIn(rel,body)
            self.assertTrue((SKILL/rel).is_file())

    def test_no_false_measurements_in_template(self):
        body=(SKILL/'assets/cockpit-scorecard.md').read_text()
        self.assertIn('não medido',body)
        self.assertIn('não configurado',body)

    def test_separation_of_observability_sources(self):
        body=(SKILL/'references/engineering-cockpit.md').read_text()
        for term in ('GitLab','Codex OTel','Application OTel','verification_state','source_system'):
            self.assertIn(term,body)

if __name__=='__main__': unittest.main()
