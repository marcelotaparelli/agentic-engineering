#!/usr/bin/env python3
"""Instala/atualiza arquivos da Agentic Engineering Team num repo Git.

Sem dependências, nunca altera o AGENTS.md ativo nem o config.toml ativo.
Conflitos são bloqueados por padrão; --update faz backup antes de atualizar.
"""
from __future__ import annotations

import argparse
import hashlib
import shutil
import sys
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path(__file__).resolve().parent
SKILL = Path('.agents/skills/agentic-engineering-team')
ROLES = Path('.codex/agents')
EXTRAS = (Path('.codex/config.example.toml'), Path('AGENTS.example.md'))


def sha(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def files_to_install() -> list[Path]:
    files = [p.relative_to(ROOT) for d in (SKILL, ROLES) for p in (ROOT / d).rglob('*') if p.is_file() and '__pycache__' not in p.parts and p.suffix != '.pyc']
    files.extend(EXTRAS)
    return sorted(files)


def check_no_symlinks(repo: Path, rel: Path) -> None:
    path = repo
    for component in rel.parts:
        path = path / component
        if path.is_symlink():
            raise ValueError(f'Link simbólico não permitido no destino: {path}')


def plan(repo: Path) -> list[tuple[Path, str]]:
    result = []
    for rel in files_to_install():
        src = ROOT / rel
        if not src.is_file() or src.is_symlink():
            raise ValueError(f'Arquivo de origem inválido: {src}')
        check_no_symlinks(repo, rel)
        dst = repo / rel
        if dst.is_file():
            state = 'unchanged' if sha(dst) == sha(src) else 'conflict'
        elif dst.exists():
            raise ValueError(f'Destino não é arquivo: {dst}')
        else:
            state = 'new'
        result.append((rel, state))
    return result


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--repo', type=Path, required=True, help='Caminho do repositório Git de destino')
    parser.add_argument('--dry-run', action='store_true', help='Exibir alterações sem escrever')
    parser.add_argument('--update', action='store_true', help='Backup e substituição de arquivos divergentes')
    args = parser.parse_args(argv)
    repo = args.repo.expanduser().resolve()
    if not repo.is_dir() or not (repo / '.git').exists():
        print('ERRO: --repo deve apontar para a raiz de um repositório Git (diretório ou worktree).', file=sys.stderr)
        return 2
    try:
        changes = plan(repo)
        conflicts = [p for p, state in changes if state == 'conflict']
        for rel, state in changes:
            print(f'{state.upper():9} {rel.as_posix()}')
        if conflicts and not args.update:
            print('\nBLOQUEADO: conflitos detectados. Inspecione os arquivos; rode --update para backup e substituição.', file=sys.stderr)
            return 1
        if args.dry_run:
            print('\nDRY-RUN: nenhum arquivo escrito.')
            return 0
        backup_root: Path | None = None
        if conflicts:
            stamp = datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%SZ')
            n = 0
            while True:
                name = stamp if n == 0 else f'{stamp}-{n}'
                candidate = repo / '.agentic-backups' / name
                if not candidate.exists() and not candidate.is_symlink():
                    backup_root = candidate
                    break
                n += 1
            check_no_symlinks(repo, Path('.agentic-backups') / name)
            # Faça todos os backups antes de alterar qualquer arquivo.
            for rel in conflicts:
                target = backup_root / rel
                target.parent.mkdir(parents=True, exist_ok=True)
                shutil.copy2(repo / rel, target)
        written = 0
        for rel, state in changes:
            if state == 'unchanged':
                continue
            target = repo / rel
            target.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(ROOT / rel, target)
            written += 1
        print(f'\nOK: {written} arquivos instalados/atualizados.')
        if backup_root:
            print(f'Backup: {backup_root} (privado: adicione .agentic-backups/ ao .gitignore)')
        print('ATENÇÃO: mescle manualmente config.example.toml e AGENTS.example.md; não ficam ativos sozinhos.')
        return 0
    except (ValueError, OSError) as exc:
        print(f'ERRO: {exc}', file=sys.stderr)
        return 2


if __name__ == '__main__':
    raise SystemExit(main())
