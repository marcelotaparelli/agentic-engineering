# Agentic Engineering Team — Starter Kit para Codex (v1.1 observability)

Kit de engenharia agêntica **sob demanda**, com skill, 9 papéis de especialistas e templates. A sessão principal do Codex assume o papel de Tech Lead. Não é um aplicativo orquestrador externo, não executa deploy automaticamente e não instala dependências.

## Instalação em um projeto

1. Extraia o ZIP na **raiz de um repositório Git** (arquivos em `.agents/skills/` e `.codex/agents/`). Não substitua arquivos preexistentes sem revisar o diff.
2. Faça merge **manual** de `.codex/config.example.toml` para a configuração efetiva (`~/.codex/config.toml` ou `.codex/config.toml`, conforme seu ambiente e trust do repositório).
3. Se for útil, integre `AGENTS.example.md` às regras existentes de `AGENTS.md`. Não duplique regras e não sobrescreva o arquivo existente.
4. Reinicie o Codex se a skill ou agentes não forem reconhecidos. Na raiz do repo: `codex` e invoque `$agentic-engineering-team Planeje e execute [tarefa]`.
5. Use `/subagents` para acompanhar os agentes; verifique as opções suportadas na versão instalada.

### Começo rápido

```text
$agentic-engineering-team
Tarefa: adicionar [funcionalidade].
Critérios de aceite: [testes/contratos].
Orquestre apenas os agentes necessários. Mostre plano e critérios de aceite antes das mudanças; implemente, valide e reporte evidências. Não faça push/deploy.
```

Para uma task simples: `$agentic-engineering-team Corrija [bug]. Use apenas um agente se o escopo permitir.`

## Estrutura

- `.agents/skills/agentic-engineering-team/SKILL.md`: workflow principal de baixo custo de contexto.
- `.../references/`: playbook, papéis, tokens, políticas e métricas sob demanda, inclusive `agent-observability.md` (custo/tokens da equipe) e `application-observability.md` (métricas/traces/logs/segurança da aplicação).
- `.../assets/`: templates de task, handoff, ADR, contrato de telemetria, runbook, gates e opt-in OTel Codex (`codex-otel.user.example.toml`).
- `.../scripts/`: validador e registro LOCAL de métricas (sem network/API).
- `.codex/agents/*.toml`: 9 especialistas; `explorer` e `worker` são nativos do Codex.
- `.codex/config.example.toml`: fragmento para instalação manual (NÃO ativo).
- `AGENTS.example.md`: políticas permanentes enxutas (NÃO ativo).

## Segurança

**Subagentes nativos podem compartilhar filesystem/permissões com a sessão principal.** Instruções de não editar não são sandbox read-only. Evite edição concorrente dos mesmos arquivos. Para editores independentes, abra sessões Codex em Git worktrees isoladas. Gates são CI/políticas/autorização humana; não confie em "aprovado" por outro LLM como prova.

## Validar kit

```bash
python3 .agents/skills/agentic-engineering-team/scripts/validate_skill.py .
python3 -m unittest discover -s .agents/skills/agentic-engineering-team/scripts/tests -v
```

## Duas observabilidades, responsabilidades diferentes

**Agentes/Codex:** Tech Lead coleta tokens/cache, duração, custo *observado*, retries, falhas e CI. Exporte OTel apenas com opt-in global em `~/.codex/config.toml`, nunca no projeto. Exemplo seguro em `assets/codex-otel.user.example.toml` (`log_user_prompt=false`). A telemetria disponível pode não individualizar subagentes automaticamente.

**Aplicação em produção:** SRE define SLI/SLO, métricas/latência, traces correlacionados, logs estruturados, eventos de segurança e runbooks. Backend/Frontend instrumentam, DevOps configura coleta/alertas, Security verifica privacidade e detecção; Test verifica evidências. A instrumentação deve sobreviver à ausência dos agentes e ter gate de release proporcional ao risco.

Para serviços, consulte `references/application-observability.md` e preencha `assets/telemetry-contract.md`. Nenhum Collector/Prometheus/Loki/Tempo é instalado pelo ZIP; a skill orienta o Codex a gerar/aplicar mudanças somente quando autorizado.

## Medir tarefas sem simular telemetria

O script recebe **medidas reais informadas pelo operador** ou exportadas das ferramentas, não coleta tokens do Codex sozinho:

```bash
python3 .agents/skills/agentic-engineering-team/scripts/task_metrics.py record \
  --file .agentic-metrics/tasks.jsonl --id example-1 --tier standard \
  --duration-sec 360 --input-tokens 8000 --output-tokens 2000 --ci-pass yes --rework 0
python3 .agents/skills/agentic-engineering-team/scripts/task_metrics.py report --file .agentic-metrics/tasks.jsonl
```

Para registrar **por invocação de especialista** (valores reais informados):

```bash
python3 .agents/skills/agentic-engineering-team/scripts/agent_usage.py record \
  --file .agentic-metrics/agents.jsonl --task-id t-123 --run-id t-123-r1 \
  --agent backend_engineer --model modelo-real --status success \
  --input-tokens 1000 --output-tokens 250 --cached-input-tokens 100 --duration-ms 5000 \
  --source codex_export
python3 .agents/skills/agentic-engineering-team/scripts/agent_usage.py report \
  --file .agentic-metrics/agents.jsonl
```

`--cost-usd` só quando valor faturado ou calculado com tarifa confiável; ausência não vira zero.

Adicione `.agentic-metrics/` ao `.gitignore` se os registros forem privados. Nenhum número de benchmark ou tokens é gerado automaticamente.

## Fontes / versão

Compatível conceitualmente com os recursos documentados do Codex em **24/10/2026**. Confira sua versão do CLI; especificações de configs e modelos podem evoluir.

- https://learn.chatgpt.com/docs/build-skills
- https://learn.chatgpt.com/docs/agent-configuration/subagents
- https://learn.chatgpt.com/docs/config-file/config-reference
- https://learn.chatgpt.com/docs/developer-commands
- https://opentelemetry.io/docs/specs/semconv/http/http-metrics/
- https://opentelemetry.io/docs/collector/
- https://cheatsheetseries.owasp.org/cheatsheets/Logging_Cheat_Sheet.html
- https://developers.openai.com/blog/rethinking-skills-and-prompts-for-gpt-6-astra
