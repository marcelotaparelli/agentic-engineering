# ADR-<id>: <decisão>

**Status:** proposed | accepted | superseded
**Contexto:** problema, requisitos não funcionais e restrições
**Opções:** 2-3 opções reais com trade-offs
**Decisão:** opção e motivo
**Consequências:** custo, complexidade, risco, operabilidade e reversibilidade
**Validação:** experimento, teste ou métrica que confirmará a decisão
