# Fluxo SDLC proporcional ao risco

| Tier | Exemplo | Agentes | Gates mínimos |
|---|---|---|---|
| quick | copy, CSS local, bug restrito | Tech Lead sozinho por padrão | diff, teste específico; impacto em telemetria avaliado ou N/A justificado |
| standard | endpoint novo, módulo isolado | Engineer + Test; SRE quando superfície operacional relevante | testes + observabilidade de erros/latência/logs/traces proporcionais ao código alterado |
| critical | auth, multitenancy, migrar DB, infra/prod | Architect + Security + executor + Test/QA + SRE/DevOps | threat model, testes negativos, observabilidade+auditoria da aplicação verificadas, runbook, CI protegido e aprovação humana |

## Fases

1. **Intake**: requisito, escopo, invariantes, contratos, definição de pronto.
2. **Design**: mini ADR só para decisão duradoura ou trade-off não trivial. Preferir design simples e compatível com arquitetura existente.
3. **Plan**: decompor no máximo em 3 linhas paralelas. Carimbar ownership por arquivo. Identificar recursos mutáveis compartilhados (banco, migrations, config).
4. **Build**: mudanças pequenas, testes cedo, commits reversíveis (nunca forçados ou automáticos sem autorização explícita).
5. **Verify**: executar gates determinísticos; quando aplicável, exercitar sucesso/erro/authz negada e provar geração/correlação de métrica, trace e log seguro; reportar resultados de comandos. Reviews LLM agregam cobertura, não substituem CI.
6. **Integrate**: comparar com base, resolver conflitos, executar suite integrada, PR/MR com evidências.
7. **Deploy**: aprovação + plano de rollout/rollback + dashboard, alerta e runbook testáveis + validação pós-deploy, apenas após autorização.
8. **Learn**: comparar tempo, custo e retrabalho com baseline single-agent; correlacionar incidentes/regressões pós-release ao commit, sem misturar PII ou conteúdo de usuários aos dados dos agentes.

## Anti-padrões

- Spawn de todos os papéis por padrão.
- Nove especialistas repetindo a leitura de todo o repo.
- Review circular: o mesmo agente escreve e certifica o próprio código.
- Paralelismo de código no mesmo working tree.
- Repetir build/test completo após cada microedição, sem sinal de benefício.
- "Passou" baseado em texto sem execução real.
- Ganhos de performance inventados ou custos calculados de tokens estimados como se fossem faturamento.

## Critérios de saída da tarefa

Mudança funcional comprovada, testes relevantes (ou falha explicitada), impacto de segurança e operações identificado, aplicação instrumentada quando necessário (métricas, traces, logs, sinais de segurança), diff inspecionado, evidências vinculadas ao commit final. Fatores bloqueantes não são omitidos para declarar conclusão.
