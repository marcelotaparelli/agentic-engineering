# Changelog — Agentic Engineering Team

## v1.5 — Technical Ownership (25/10/2026)

- Adicionado `technical_ownership_mentor` (12º especialista) com revisão centrada no código, teste e commit reais.
- Protocolo progressivo `passive|guided|deep`, acionamento por risco e custo proporcional.
- `ownership-card.md` e `ownership-ledger.md` permitem identificar lacunas reais de compreensão, status por versão e exercícios práticos.
- Especificação do Cockpit inclui instrumento de propriedade técnica e eventos normalizados de conhecimento; **não há dashboard ou monitoramento automático neste ZIP**.
- README inclui prompt G de revisão técnica; validador e testes ampliados.

## v1.4 — Quick Start e Engineering Cockpit (25/10/2026)

- README ampliado com prompts prontos: aplicação nova, aprovação, onboarding, trabalho diário, release/incidente e início do cockpit.
- Especificação `references/engineering-cockpit.md` e template `assets/cockpit-scorecard.md` para visão executiva, dados auditáveis e integração progressiva.
- Skill orienta apresentação executiva de dados observados, sem simular um dashboard operacional ou custos não medidos.
- Testes de documentação e integridade adicionais; mantendo 11 especialistas, configurados sob demanda.

## v1.3 — auditoria e documentação (25/10/2026)

- README reescrito e incluído também dentro da pasta da skill para instalação, atualização, uso diário, papéis, observabilidade de agentes e aplicação, economia de tokens, Challenger/Red Team, gates e troubleshooting.
- Instalador conservador `install.py`: dry-run, recusa conflitos por padrão, atualização com backup, recusa symlinks de destino. Nunca muda AGENTS.md ou config.toml ativos.
- Gate declarativo: opção `--expected-commit`, coerência com SHA de verificação, validações adicionais de modo Red Team e evidência para fechar achados HIGH/CRITICAL.
- Corrigido exemplo de configuração OTel global: a v1.2 misturava valor scalar com subtabela TOML, tornando o exemplo inválido. Agora há configuração inline válida (opt-in).
- Validador da skill reforçado com checagem de referências locais e exemplo OTel TOML.
- Testes novos para gate e instalação. Sem dependências externas.
- **Sem mudança de arquitetura de 11 especialistas.** Ainda requer testes reais no Codex, CI e ambiente da aplicação. Revisão de relatório não substitui proteção de branch, evidência de CI nem aprovação humana.

## v1.2

- Engineering Challenger e Adversarial Security Tester; protocolos, ROE e review gate.

## v1.1

- Observabilidade de agentes e aplicação, telemetria, métricas e runbooks.
